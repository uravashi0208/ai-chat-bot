const Message = require('../models/Message');
const { verifyAccessToken } = require('../config/jwt');
const logger = require('../utils/logger');

const onlineUsers = new Map();

const setupSocket = (io) => {
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth.token;
      if (!token) {
        return next(new Error('Authentication error'));
      }

      const decoded = verifyAccessToken(token);
      socket.userId = decoded.userId;
      socket.username = decoded.username;
      next();
    } catch (error) {
      logger.error(`Socket auth error: ${error.message}`);
      next(new Error('Authentication error'));
    }
  });

  io.on('connection', (socket) => {
    const { userId, username } = socket;
    
    // Add user to online list
    onlineUsers.set(userId, socket.id);
    logger.info(`User connected: ${username} (${userId})`);

    // Notify all users about new connection
    io.emit('user_online', { userId, username });

    // Handle private messages
    socket.on('send_message', async ({ receiverId, content, tempId }, callback) => {
      try {
        // Validate input
        if (!content || !receiverId) {
          throw new Error('Message content and receiver ID are required');
        }

        // Save to database
        const message = await Message.create({
          sender_id: userId,
          receiver_id: receiverId,
          content
        });

        // Prepare response
        const messageData = {
          id: message.id,
          senderId: userId,
          senderUsername: username,
          receiverId,
          content,
          sentAt: message.sent_at,
          tempId
        };

        // Send to receiver if online
        const receiverSocketId = onlineUsers.get(receiverId);
        if (receiverSocketId) {
          io.to(receiverSocketId).emit('receive_message', messageData);
        }

        // Confirm to sender
        callback({ 
          success: true, 
          message: messageData 
        });

      } catch (error) {
        logger.error(`Message error: ${error.message}`);
        callback({ 
          success: false, 
          error: error.message,
          tempId 
        });
      }
    });

    // Handle disconnection
    socket.on('disconnect', () => {
      onlineUsers.delete(userId);
      io.emit('user_offline', { userId });
      logger.info(`User disconnected: ${username} (${userId})`);
    });
  });
};

module.exports = { setupSocket, onlineUsers };