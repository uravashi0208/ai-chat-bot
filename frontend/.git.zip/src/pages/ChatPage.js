import React, { useState, useEffect, useRef } from 'react';
import { useSocket } from '../context/SocketContext';
import { useAuth } from '../context/AuthContext';
import { getUsers, getMessages, sendMessage } from '../api/chat';
import '../assets/styles/whatsapp.css';

const ChatPage = () => {
  const { user, logout } = useAuth();
  const socket = useSocket();
  const [users, setUsers] = useState([]);
  const [messages, setMessages] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [inputMessage, setInputMessage] = useState('');
  const messagesEndRef = useRef(null);

  // Fetch users and initial messages
  useEffect(() => {
    const fetchData = async () => {
      const usersList = await getUsers();
      setUsers(usersList);
      if (usersList.length > 0) {
        setSelectedUser(usersList[0]);
      }
    };
    fetchData();
  }, []);

  // Fetch messages when selected user changes
  useEffect(() => {
    if (selectedUser) {
      const fetchMessages = async () => {
        const chatMessages = await getMessages(selectedUser.id);
        setMessages(chatMessages);
      };
      fetchMessages();
    }
  }, [selectedUser]);

  // Socket message handling
  useEffect(() => {
    if (!socket || !selectedUser) return;

    const handleNewMessage = (message) => {
      if (message.sender_id === selectedUser.id || message.receiver_id === selectedUser.id) {
        setMessages(prev => [...prev, message]);
      }
    };

    socket.on('receive_message', handleNewMessage);
    return () => socket.off('receive_message', handleNewMessage);
  }, [socket, selectedUser]);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!inputMessage.trim() || !selectedUser) return;

    const newMessage = await sendMessage({
      receiverId: selectedUser.id,
      content: inputMessage
    });
    setMessages(prev => [...prev, newMessage]);
    setInputMessage('');
  };

  return (
    <div className="whatsapp-container">
      {/* Sidebar */}
      <div className="sidebar">
        <div className="sidebar-header">
          <div className="user-profile">
            <div className="avatar">{user?.username.charAt(0)}</div>
            <span>{user?.username}</span>
          </div>
          <button onClick={logout} className="logout-btn">Logout</button>
        </div>
        
        <div className="search-bar">
          <input type="text" placeholder="Search or start new chat" />
        </div>
        
        <div className="chat-list">
          {users.map(user => (
            <div 
              key={user.id} 
              className={`chat-item ${selectedUser?.id === user.id ? 'active' : ''}`}
              onClick={() => setSelectedUser(user)}
            >
              <div className="avatar">{user.username.charAt(0)}</div>
              <div className="chat-info">
                <div className="chat-name">{user.username}</div>
                <div className="last-message">Last message preview...</div>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Chat Area */}
      <div className="chat-area">
        {selectedUser ? (
          <>
            <div className="chat-header">
              <div className="contact-info">
                <div className="avatar">{selectedUser.username.charAt(0)}</div>
                <div>
                  <div className="contact-name">{selectedUser.username}</div>
                  <div className="status">Online</div>
                </div>
              </div>
            </div>
            
            <div className="messages-container">
              {messages.map((message, index) => (
                <div 
                  key={index} 
                  className={`message ${message.sender_id === user.id ? 'sent' : 'received'}`}
                >
                  <div className="message-content">{message.content}</div>
                  <div className="message-time">10:30 AM</div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>
            
            <form className="message-input" onSubmit={handleSendMessage}>
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder="Type a message"
              />
              <button type="submit">
                <svg viewBox="0 0 24 24" width="24" height="24">
                  <path fill="currentColor" d="M1.101 21.757L23.8 12.028 1.101 2.3l.011 7.912 13.623 1.816-13.623 1.817-.011 7.912z"></path>
                </svg>
              </button>
            </form>
          </>
        ) : (
          <div className="no-chat-selected">
            <div className="placeholder">
              <h2>WhatsApp Web</h2>
              <p>Select a chat to start messaging</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ChatPage;