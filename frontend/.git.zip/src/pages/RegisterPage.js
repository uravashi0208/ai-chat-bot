import React from 'react';
import RegisterForm from '../components/Auth/RegisterForm';

const RegisterPage = () => {
  return <RegisterForm />;
};

export default RegisterPage;